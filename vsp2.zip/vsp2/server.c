
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "port.h"

#define BUFSIZE 2048

int
main(int argc, char **argv)
{
	struct sockaddr_in myaddr;	/* our address */
	struct sockaddr_in remaddr;	/* remote address */
	socklen_t addrlen = sizeof(remaddr);		/* length of addresses */
	int recvlen;			/* # bytes received */
	int fd;				/* our socket */
	int msgcnt = 0;			/* count # of messages we received */
	unsigned char buf[BUFSIZE];	/* receive buffer */
	int S1,S2,S3,S4 = 0;
	unsigned char test1[BUFSIZE];
	unsigned char test2[BUFSIZE]; 
	unsigned char test3[BUFSIZE]; 	
	unsigned char test4[BUFSIZE]; 

	/* create a UDP socket */

	if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror("cannot create socket\n");
		return 0;
	}

	/* bind the socket to any valid IP address and a specific port */

	memset((char *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	myaddr.sin_port = htons(SERVICE_PORT);

	if (bind(fd, (struct sockaddr *)&myaddr, sizeof(myaddr)) < 0) {
		perror("bind failed");
		return 0;
	}

	/* now loop, receiving data and printing what we received */
	for (;;) {
		char tmp = 'a';
		
		printf("waiting on port %d\n", SERVICE_PORT);
		recvlen = recvfrom(fd, buf, BUFSIZE, 0, (struct sockaddr *)&remaddr, &addrlen);
		struct sockaddr_in *sin = (struct sockaddr *)&remaddr;	// getting sender IP adress
		if (recvlen > 0) {
			buf[recvlen] = 0;
			unsigned char *ip = (unsigned char *)&sin->sin_addr.s_addr;
			tmp=buf[0];
			//sscanf(tmp, "%d", &tmpi);
			printf("MSG from!%d.%d.%d.%d ", ip[0], ip[1], ip[2], ip[3]);
			printf("cotains: %s \n", buf);
			//printf("inhalt! %c\n",tmp);
			memmove (buf, buf+1, strlen (buf+1) + 1);

			switch(tmp){
			case '1': printf("Sie fahren %s kmh!\n",buf);memcpy(test1,buf,strlen(buf)+1) ;S1 = 0; break;
			case '2': printf("Sie haben %s Kilometer auf dem Tacho!\n",buf);memcpy(test2,buf,strlen(buf)+1) ;S2= 0; break;
			case '3': printf("Momentane verkehrslage: %s!\n",buf);memcpy(test3,buf,strlen(buf)+1) ;S3=0; break;
			case '4': printf("Ihr Tank ist zu:%s prozent voll!\n",buf);memcpy(test4,buf,strlen(buf)+1) ;S4=0; break;
			}

		}
		else
			printf("uh oh - something went wrong!\n");
		S1++;
		S2++;
		S3++;
		S4++;
		if(S1 > 20)
		printf("Error! kmh sensor out of date\n");
		if(S2 > 20)
		printf("Error! Tacho out of date\n");
		if(S3 > 20)
		printf("Error! Verkehrssensor ouf of date\n");
		if(S4 > 4)
		printf("Error! Tank sensor out of date\n");
		FILE *f = fopen("stats.txt", "w");
		if (f == NULL)
		{
   		 printf("Error opening file!\n");
   		 exit(1);
		}
		
		/* print some text */
		
		fprintf(f, "Sie fahren %s kmh!\nSie haben %s Kilometer auf dem Tacho!\nMomentane verkehrslage: %s!\nIhr Tank ist zu:%s prozent voll!\n", test1,test2,test3,test4);



		fclose(f);
	
	}
	/* never exits */
}

