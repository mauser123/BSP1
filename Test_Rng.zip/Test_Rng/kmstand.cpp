#include <cstdlib>
#include <iostream>
//#include <thread>  //windows
//#include <chrono>  // windows
#include <unistd.h> //Linux
using namespace std;
int main(int argc, char** argv) {
    double KM_Stand = 25291.4;    
    while(true){    
    int r = rand()%100;
    if(r >= 90){
    KM_Stand+=5;
    }
    else if((r <= 89) && (r >=70)){
    KM_Stand+=4;   
    }
    else if((r <= 69) && (r >=40)){
     KM_Stand+=1.3;   
    }
    else if((r <= 39) && (r >=0)){
     KM_Stand+=0.5;    
    }
   
    cout<<"Sie sind bereits "<<KM_Stand<<" Kilometer gefahren!"<<endl;
    
    //std::this_thread::sleep_for(std::chrono::milliseconds(1000));   // windows
    sleep(1); //Linux
    }
    return 0;
}


