#include <cstdlib>
#include <iostream>
//#include <thread>  //windows
//#include <chrono>  // windows
#include <unistd.h> //Linux
using namespace std;
int main(int argc, char** argv) {
    double tank = 100.00;    
    while(true){    
    int r = rand()%100;
    if(r >= 90){
    tank-=2.2;
    }
    else if((r <= 89) && (r >=70)){
    tank-=1.5;   
    }
    else if((r <= 69) && (r >=40)){
    tank-=1.0;    
    }
    else if((r <= 39) && (r >=0)){
    tank-=0.5;    
    }
    if(tank <= 0.00){
        cout<<"Tank ist leer!"<<endl;
        return 0;
    }
    cout<<"Ihr Tank ist zu "<<tank<<": Prozent gefüllt"<<endl;
    
    //std::this_thread::sleep_for(std::chrono::milliseconds(1000));   // windows
    sleep(1); //Linux
    }
    return 0;
}


