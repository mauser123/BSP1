#include <cstdlib>
#include <iostream>
//#include <thread>
//#include <chrono>
#include <unistd.h>

using namespace std;
int main(int argc, char** argv) {
    
    int kmh = 25; 
    while(true){
    int r = rand()%100;
    if(r >= 50){
    kmh+=25;
    if(kmh > 130){
        kmh = 130;
    }
    }
    else{
    kmh -= 15; 
    if(kmh <0){
        kmh = 30;
    }
    }
    cout<<"Sie fahren:"<<kmh<<"km/h"<<endl;
    //std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    sleep(1);
    }
    return 0;
}
