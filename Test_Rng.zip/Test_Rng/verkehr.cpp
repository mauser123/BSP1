#include <cstdlib>
#include <iostream>
#include <string>
#include <string>
//#include <thread>  //windows
//#include <chrono>  // windows
#include <unistd.h> //Linux
using namespace std;
int main(int argc, char** argv) {
        
    while(true){
    string tmp;    
    int r = rand()%100;
    if(r >= 90){
    tmp ="Stau";
    }
    else if((r <= 89) && (r >=70)){
    tmp ="starker Verkehr";    
    }
    else if((r <= 69) && (r >=40)){
    tmp ="maessiger Verkehr";    
    }
    else if((r <= 39) && (r >=0)){
    tmp ="frei";    
    }
    cout<<tmp<<endl;
    //std::this_thread::sleep_for(std::chrono::milliseconds(1000));   // windows
    sleep(1); //Linux
    }
    return 0;
}


